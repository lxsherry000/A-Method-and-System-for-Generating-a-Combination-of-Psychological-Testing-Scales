#!/usr/bin/env python
# -*- coding:utf-8 -*-

from calculator import *

scale_mapping = {
    "1-MHRSP": {
        "学习障碍": "7-SH",
        "情绪障碍": "4-DSRSC",
        "性格缺陷": "16-CC",
        "社会适应障碍": "6-AA",
        "品德缺陷": "59-MB",
        "不良习惯": "60-BA",
        "行为障碍": "61-CS",
        "特种障碍": "62-DBAS16"
    },
    "2-MSSMHS": {
        "强迫症状": "61-CS",
        "偏执": "63-PP",
        "敌对": "64-HM",
        "人际关系紧张与敏感": "56-IC",
        "抑郁": "48-DASS21",
        "焦虑": "5-SAS",
        "学习压力": "10-TAT",
        "适应不良": "24-MA",
        "情绪不平衡": "18-SCARED",
        "心理不平衡": "41-EP"
    },
    "3-SCL90": {
        "躯体化": "25-ST",
        "强迫症状": "61-CS",
        "人际关系敏感": "56-IC",
        "抑郁": "48-DASS21",
        "焦虑": "5-SAS",
        "敌对": "64-HM",
        "恐怖": "65-PDSS",
        "偏执": "63-PP",
        "精神病性": "66-BPRS",
        "其他": "62-DBAS16"
    }
}

function_mapping = {
    "1-MHRSP": calculate1,
    "2-MSSMHS": calculate2,
    "3-SCL90": calculate3,
    "4-DSRSC": calculate4,
    "5-SAS": calculate5,
    "6-AA": calculate6,
    "7-SH": calculate7,
    "10-TAT": calculate10,
    "16-CC": calculate16,
    "18-SCARED": calculate18,
    "24-MA": calculate24,
    "25-ST": calculate25,
    "41-EP": calculate41,
    "48-DASS21": calculate48,
    "56-IC": calculate56,
    "59-MB": calculate59,
    "60-BA": calculate60,
    "61-CS": calculate61,
    "62-DBAS16": calculate62,
    "63-PP": calculate63,
    "64-HM": calculate64,
    "65-PDSS": calculate65,
    "66-BPRS": calculate66,
}
