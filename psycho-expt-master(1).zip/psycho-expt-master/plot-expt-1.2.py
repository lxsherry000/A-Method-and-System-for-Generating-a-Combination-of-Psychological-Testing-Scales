import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator

# 轻度 中等 重度 严重
composite_scale = ["Mild", "Moderate", "Severe", "Serious"]

# 折线图坐标
size = len(composite_scale)
x = np.arange(size)
bar_colors = ['#ff8080', '#90EE90', '#8080ff']  # 为每组数据分配颜色
data = {
    "MHRSP": [43.36, 36.27, 9.44, 9.44],
    "MSSMHS": [44.67, 25.01, 8.33, 7.52],
    "SCL-90": [57.76, 52.75, 43.65, 38.34],
}

fig = plt.figure()
ax1 = fig.add_subplot(111)

# 设置刻度间隔
y_major_locator = MultipleLocator(10)
ax1.yaxis.set_major_locator(y_major_locator)

# 绘制每组折线图
for i, (key, color) in enumerate(zip(data.keys(), bar_colors)):
    ax1.plot(x, data[key], color=color, marker='o', label=key)

ax1.set_ylim(bottom=0, top=100)
ax1.set_ylabel('Time (min)')
ax1.set_xlabel('Positive Threshold')
ax1.legend(loc='upper right')

plt.xticks(x, labels=composite_scale)
plt.title("The algorithm's time consumption for different scales")

plt.show()




