import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator

# 轻度 中等 重度 严重
composite_scale = ["Mild", "Moderate", "Severe", "Serious"]

data = {
    "MHRSP": [50.59, 70.22, 63.62, 62.50],
    "MSSMHS": [57.38, 80.17, 66.03, 60.02],
    "SCL-90": [60.52, 66.85, 80.21, 82.11],
}

################################################################

# 双轴：https://zhuanlan.zhihu.com/p/343719623
# 图形：https://blog.csdn.net/weixin_45891612/article/details/129082746
# 颜色：https://blog.csdn.net/weixin_43697287/article/details/88876680
# 花纹：https://matplotlib.org/2.0.2/examples/pylab_examples/hatch_demo.html
# 图例：https://blog.csdn.net/Wannna/article/details/102751689

size = len(composite_scale)
x = np.arange(size)
width_bar = 0.2  # 调整柱状图的宽度
bar_colors = ['#ff8080', '#90EE90', '#8080ff']  # 为每组柱状图分配颜色

################################################################

fig = plt.figure()
ax1 = fig.add_subplot(111)

# 设置刻度间隔
y_major_locator = MultipleLocator(10)
ax1.yaxis.set_major_locator(y_major_locator)

pattern = ['-', '/', 'o']
# 绘制每组柱状图
for i, (key, color, pattern) in enumerate(zip(data.keys(), bar_colors, pattern)):
    ax1.bar(x + i * width_bar, data[key], width=width_bar, color=color, hatch=pattern, label=key)

ax1.set_ylim(bottom=0, top=100)
ax1.set_ylabel('Accuracy (%)')
ax1.set_xlabel('Positive Threshold')
ax1.legend(loc='upper right')

plt.xticks(x + width_bar, labels=composite_scale)
plt.title("The algorithm's accuracy for different scales")

plt.show()

# exp_1_1:
# 耗时：[43.36, 47.06, 42.5, 38.74]
# 准确率：[50.16, 50.96, 50.64, 50.59]

# 耗时：[34.52, 36.27, 31.6, 38.1]
# 准确率：[70.09, 70.33, 70.38, 70.22]

# 耗时：[9.44, 9.44, 9.44, 9.45]
# 准确率：[63.62, 63.67, 63.73, 64.0]

# 耗时：[9.44, 9.44, 9.44, 9.44]
# 准确率：[62.5, 62.5, 62.5, 62.5]

# exp_1_2:
# 耗时：[44.67, 25.01, 8.33, 7.52]
# 准确率：[57.38, 80.17, 66.03, 60.02]

# exp_1_3:
# 耗时：[53.98, 57.76, 58.02, 52.35]
# 准确率：[60.66, 60.61, 60.95, 60.52]

# 耗时：[55.44, 52.75, 55.62, 52.46]
# 准确率：[67.11, 66.85, 67.03, 66.82]

# 耗时：[43.65, 44.15, 46.72, 42.39]
# 准确率：[80.21, 81.13, 80.1, 80.61]

# 耗时：[38.34, 39.16, 37.06, 39.12]
# 准确率：[82.11, 82.36, 82.53, 81.93]
