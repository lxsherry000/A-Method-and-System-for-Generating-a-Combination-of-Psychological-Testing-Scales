import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator

# 轻度 中等 重度 严重
composite_scale = ["Delete Point 1/3", "Delete Point 2", "Delete Point 3", "Our Method"]

Data = {
    "time": [9.25, 23.74, 23.61, 23.62],
    "accuracy": [61.92, 47.91, 48.13, 83.77],
}

################################################################

# 双轴：https://zhuanlan.zhihu.com/p/343719623
# 图形：https://blog.csdn.net/weixin_45891612/article/details/129082746
# 颜色：https://blog.csdn.net/weixin_43697287/article/details/88876680
# 花纹：https://matplotlib.org/2.0.2/examples/pylab_examples/hatch_demo.html
# 图例：https://blog.csdn.net/Wannna/article/details/102751689

# 柱状图坐标
size = len(composite_scale)
x = np.arange(size)
width_bar = 0.3
# Alg_x = x
# Ours_x = x
# Security_x = x
# 刻度间隔
y1_major_locator = MultipleLocator(10)
y2_major_locator = MultipleLocator(10)

bar_color_1 = '#ff8080'
bar_color_2 = '#8080ff'
plot_color = '#111111'

################################################################

fig = plt.figure()
ax1 = fig.add_subplot(111)

# ax1.bar(Alg_x, Data["Others"], width=width_bar, color=bar_color_1, hatch="--", label="Others")
ax1.bar(x, Data["accuracy"], width=width_bar, color=bar_color_1, hatch="//", label="Accuracy rate")
ax1.set_ylim(bottom=0, top=100)
ax1.yaxis.set_major_locator(y1_major_locator)

ax1.set_ylabel('Percentage (%)')
ax1.set_xlabel('Different Settings')
ax1.legend(loc=2)

ax2 = ax1.twinx()  # this is the important function

ax2.plot(x, Data["time"], color=plot_color, marker="v", label="Time consumption")
ax2.set_ylim(bottom=0, top=100)
ax2.yaxis.set_major_locator(y2_major_locator)
ax2.set_ylabel('Time (min)')
ax2.legend(loc=1)

# for i in range(size):  ##向曲线上的点添加数据标签，利用text函数
#     plt.text(Security_x[i], Data["time"][i] + 1.3, Data["time"][i], ha='center', va='bottom', fontsize=10,
#              color=plot_color)

plt.xticks(x, labels=composite_scale)
plt.title("Analysis of Innovation Contribution Degree")
plt.show()
