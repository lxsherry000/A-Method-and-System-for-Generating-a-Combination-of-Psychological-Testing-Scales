import json
import random
from calculator import *
from mapping import *

# 指定JSON文件的路径 实验一使用综合量表2
file_path = 'data/composite/1-MHRSP.json'
# 可替换为'data/composite/1-MHRSP.json' 或 'data/composite/2-MSSMHS.json' 或 'data/composite/3-SCL90.json'
# 答题数量
question_num = 0

# 病人真实症状
patientSituation = {
        "学习障碍": True,
        "情绪障碍": True,
        "性格缺陷": True,
        "社会适应障碍": True,
        "品德缺陷": True,
        "不良习惯": True,
        "行为障碍": True,
        "特种障碍": True
}

# 可替换为{
#        "学习障碍": True,
#        "情绪障碍": False,
#        "性格缺陷": False,
#        "社会适应障碍": False,
#        "品德缺陷": False,
#        "不良习惯": True,
#        "行为障碍": False,
#        "特种障碍": True
#    },
#   {
#        "强迫症状": False,
#        "偏执": True,
#        "敌对": False,
#        "人际关系紧张与敏感": False,
#        "抑郁": True,
#        "焦虑": False,
#        "学习压力": True,
#        "适应不良": False,
#        "情绪不平衡": True,
#        "心理不平衡": False
#    },
#    {
#        "躯体化": True,
#        "强迫症状": False,
#        "人际关系敏感": False,
#        "抑郁": True,
#        "焦虑": True,
#        "敌对": False,
#        "恐怖": False,
#        "偏执": True,
#        "精神病性": True,
#        "其他": True
#    }

# 病人测试结果
patientAnalysis = {
        "学习障碍": False,
        "情绪障碍": False,
        "性格缺陷": False,
        "社会适应障碍": False,
        "品德缺陷": False,
        "不良习惯": False,
        "行为障碍": False,
        "特种障碍": False
}

# 可替换为{
#        "学习障碍": False,
#        "情绪障碍": False,
#        "性格缺陷": False,
#        "社会适应障碍": False,
#        "品德缺陷": False,
#        "不良习惯": False,
#        "行为障碍": False,
#        "特种障碍": False
#    },
#    {
#        "强迫症状": False,
#        "偏执": False,
#        "敌对": False,
#        "人际关系紧张与敏感": False,
#        "抑郁": False,
#        "焦虑": False,
#        "学习压力": False,
#        "适应不良": False,
#        "情绪不平衡": False,
#        "心理不平衡": False
#    },
#    {
#        "躯体化": False,
#        "强迫症状": False,
#        "人际关系敏感": False,
#        "抑郁": False,
#        "焦虑": False,
#        "敌对": False,
#        "恐怖": False,
#        "偏执": False,
#        "精神病性": False,
#        "其他": False
#    }

def compare_similarity(dict1, dict2):
    # 如果任一字典为空，则相似度为0
    if not dict1 or not dict2:
        return 0
    # 确保两个字典有相同的键
    common_keys = set(dict1.keys()) & set(dict2.keys())
    # 计算匹配的值的数量
    matches = sum(1 for key in common_keys if dict1[key] == dict2[key])
    # 计算相似度
    similarity = (matches / len(common_keys)) * 100 if common_keys else 0

    return similarity


class MentalHealthSurvey:
    def __init__(self):
        self.name = ''
        self.option = []
        self.data = []

    def load_data(self, file_path):
        file = open(file_path, 'r', encoding='utf-8')
        # 使用split方法分割路径并获取量表名称
        self.name = file_path.split('/')[-1].split('.')[0]
        # 从json加载数据
        parsed_data = json.load(file)
        # 获取选项集合
        ruleList = parsed_data.get('rules', [])
        for rule in ruleList:
            for option in rule['options']:
                if option['option'] not in self.option:
                    self.option.append(option['option'])
        self.option.sort()
        # 获取题目数据
        self.data = parsed_data.get('data', [])

    def get_symptoms(self):
        # 返回所有症状名称
        return [item['symptom'] for item in self.data]

    def get_questions_by_symptom(self, symptom):
        # 根据症状名称获取相关问题
        for item in self.data:
            if item['symptom'] == symptom:
                return item['questions']
        return None

    def make_answer(self, situation):
        if situation:
            # 当situation为True时，大概率选择靠后的选项
            if len(self.option) == 5:  # 5个选项
                option_probability = [0.10, 0.15, 0.20, 0.25, 0.30]
            else:  # 3个选项
                option_probability = [0.25, 0.35, 0.40]
            # 确保选项和概率列表的长度相同
            assert len(self.option) == len(option_probability), "选项数量和概率数量不匹配"
            # 使用random.choices并转换为字符串
            return str(random.choices(self.option, weights=option_probability, k=1)[0])
        else:
            # 当situation为False时，大概率选择靠前的选项
            if len(self.option) == 5:  # 5个选项
                option_probability = [0.30, 0.25, 0.20, 0.15, 0.10]
            else:  # 3个选项
                option_probability = [0.40, 0.35, 0.25]
            # 确保选项和概率列表的长度相同
            assert len(self.option) == len(option_probability), "选项数量和概率数量不匹配"
            # 使用random.choices并转换为字符串
            return str(random.choices(self.option, weights=option_probability, k=1)[0])


if __name__ == "__main__":

    # 速率列表
    speed_rate = [0, 0, 0, 0]
    # 准确率列表
    accuracy_rate = [0, 0, 0, 0]
    # 迭代次数
    iteration = 1000

    # 分别计算综合量表2四种不同阳性阈值的结果
    for i in range(4):
        # 初始化速率和准确率
        sr = 0
        ar = 0
        # 修改综合量表2的阳性阈值
        changeThreshold(i)
        # 每个阈值执行n次
        for _ in range(iteration):

            # 创建MentalHealthSurvey类的实例
            survey = MentalHealthSurvey()

            # 加载JSON数据
            survey.load_data(file_path)

            # 获取病症标签
            symptomList = survey.get_symptoms()

            # 对每个病症标签进行迭代
            for symptom in symptomList:
                questionList = survey.get_questions_by_symptom(symptom)
                # 模拟作答综合量表
                for question in questionList:
                    # 选择选项
                    opt_c = survey.make_answer(patientSituation[symptom])
                    # 累计问题字符串长度用于计算答题时间
                    sr += len(str(question))  # 将问题转换为字符串并计算长度
                    # 计算一阶阳性
                    result_1st = calculate1(question['id'], opt_c, symptom)
                    # calculate随量表变化
                    # result[0]: 所有病症的计分情况 result[1]: 所有病症的阳性情况
                    if result_1st[1][symptom]:
                        # 生成单测评项目量表
                        singleSurvey = MentalHealthSurvey()
                        single_name = scale_mapping[survey.name][symptom]  # 单测评项量表名称
                        single_path = f'data/single/{single_name}.json'
                        singleSurvey.load_data(single_path)
                        # 模拟作答单测评项量表
                        for singleQuestion in singleSurvey.data:
                            # 选择选项
                            opt_s = random.choice(singleSurvey.option)
                            # 累计问题字符串长度用于计算答题时间
                            sr += len(str(singleQuestion))  # 将问题转换为字符串并计算长度
                            # 计算一阶阳性
                            calculate = function_mapping[single_name]
                            result_2nd = calculate(singleQuestion['id'], opt_s)
                            # result[0]: 计分情况 result[1]: 阳性情况
                            if result_2nd[1]:
                                patientAnalysis[symptom] = True
                                break
            # 计算当前轮次的速率
            sr = sr / 5 / 60  # 转换为分钟
            # 计算当前轮次的准确率
            ar += compare_similarity(patientSituation, patientAnalysis)
            # 重置计数器
            question_num = 0
            patientAnalysis = {key: False for key in patientAnalysis}
            # 重置分数计算器
            resetCalculator()

        # 计算答题情况的均值
        speed_rate[i] = round(sr, 2)
        accuracy_rate[i] = round(ar / iteration, 2)

    print(f"耗时：{speed_rate}\n准确率：{accuracy_rate}")