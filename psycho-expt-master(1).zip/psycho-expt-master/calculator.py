#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Description: 所有量表的分数计算方法

answers = []  # 答题统计

##############################################################
# part1-综合量表 ##############################################
##############################################################

# -------------------------------------
# 量表1的参数设置：总分 病情 阳性分 映射
# -------------------------------------
totalScore1 = {
    "学习障碍": 0,
    "情绪障碍": 0,
    "性格缺陷": 0,
    "社会适应障碍": 0,
    "品德缺陷": 0,
    "不良习惯": 0,
    "行为障碍": 0,
    "特种障碍": 0
}
totalPositive1 = {
    "学习障碍": False,
    "情绪障碍": False,
    "性格缺陷": False,
    "社会适应障碍": False,
    "品德缺陷": False,
    "不良习惯": False,
    "行为障碍": False,
    "特种障碍": False
}
positiveScore1 = 10  # 7 10 16 20
scaleMap1 = {
    "A": 0,
    "B": 1,
    "C": 2
}

# -------------------------------------
# 量表2的参数设置：总分 病情 阳性分 映射
# -------------------------------------
totalScore2 = {
    "强迫症状": 0,
    "偏执": 0,
    "敌对": 0,
    "人际关系紧张与敏感": 0,
    "抑郁": 0,
    "焦虑": 0,
    "学习压力": 0,
    "适应不良": 0,
    "情绪不平衡": 0,
    "心理不平衡": 0
}
totalPositive2 = {
    "强迫症状": False,
    "偏执": False,
    "敌对": False,
    "人际关系紧张与敏感": False,
    "抑郁": False,
    "焦虑": False,
    "学习压力": False,
    "适应不良": False,
    "情绪不平衡": False,
    "心理不平衡": False
}
positiveScore2 = 18  # 12轻度 18中等 24较重 30严重 由word中均分*6得到
scaleMap2 = {
    "A": 1,
    "B": 2,
    "C": 3,
    "D": 4,
    "E": 5,
}

# -------------------------------------
# 量表3的参数设置：总分 病情 阳性分 映射
# -------------------------------------
totalScore3 = {
    "躯体化": 0,
    "强迫症状": 0,
    "人际关系敏感": 0,
    "抑郁": 0,
    "焦虑": 0,
    "敌对": 0,
    "恐怖": 0,
    "偏执": 0,
    "精神病性": 0,
    "其他": 0
}
totalPositive3 = {
    "躯体化": False,
    "强迫症状": False,
    "人际关系敏感": False,
    "抑郁": False,
    "焦虑": False,
    "敌对": False,
    "恐怖": False,
    "偏执": False,
    "精神病性": False,
    "其他": False
}
positiveScore3 = {
    "躯体化": 31,       # 17 22 28 31
    "强迫症状": 31,      # 17 22 28 31
    "人际关系敏感": 27,   # 14 19 24 27
    "抑郁": 36,         # 22 27 33 36
    "焦虑": 28,         # 13 18 24 28
    "敌对": 20,         # 9 12 16 20
    "恐怖": 18,         # 8 11 15 18
    "偏执": 19,         # 8 12 15 19
    "精神病性": 27,      # 12 17 24 27
    "其他": 22          # 10 14 19 22
}
scaleMap3 = {
    "A": 1,
    "B": 2,
    "C": 3,
    "D": 4,
    "E": 5,
}


def calculate1(num, opt, symptom):
    '''
    计算综合量表1的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :param symptom: 病症因子
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore1, totalPositive1  # 声明为全局变量
    answers.append(["composite1", num, opt])  # 记录答题情况
    totalScore1[symptom] += scaleMap1[opt]  # 新增分数
    isPositive = True if totalScore1[symptom] >= positiveScore1 else False  # 是否为阳性
    totalPositive1[symptom] = isPositive  # 记录病症因子的阳性情况

    return [totalScore1, totalPositive1]


def calculate2(num, opt, symptom):
    '''
    计算综合量表2的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :param symptom: 病症因子
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore2, totalPositive2  # 声明为全局变量
    answers.append(["composite2", num, opt])  # 记录答题情况
    totalScore2[symptom] += scaleMap2[opt]  # 新增分数
    isPositive = True if totalScore2[symptom] >= positiveScore2 else False  # 是否为阳性
    totalPositive2[symptom] = isPositive  # 记录病症因子的阳性情况

    return [totalScore2, totalPositive2]


def calculate3(num, opt, symptom):
    '''
    计算综合量表3的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :param symptom: 病症因子
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore3, totalPositive3  # 声明为全局变量
    answers.append(["composite3", num, opt])  # 记录答题情况
    totalScore3[symptom] += scaleMap3[opt]  # 新增分数
    isPositive = True if totalScore3[symptom] >= positiveScore3[symptom] else False  # 是否为阳性
    totalPositive3[symptom] = isPositive  # 记录病症因子的阳性情况

    return [totalScore3, totalPositive3]


##############################################################
# part2-单测评项量表 ##########################################
##############################################################

# -------------------------------------
# 量表4的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore4 = 0
positiveScore4 = 15  # 根据量表word得出
scaleMap4_1 = {
    "A": 0,
    "B": 1,
    "C": 2
}
scaleMap4_2 = {
    "A": 2,
    "B": 1,
    "C": 0
}

# -------------------------------------
# 量表5的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore5 = 0
positiveScore5 = 50  # 根据量表word得出
scaleMap5 = {
    "A": 1,
    "B": 2,
    "C": 3,
    "D": 4,
}

# -------------------------------------
# 量表6的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore6 = 0
positiveScore6 = 60  # 根据量表word得出
scaleMap6 = {
    "A": 1,
    "B": 2,
    "C": 3,
    "D": 4,
    "E": 5
}

# -------------------------------------
# 量表7的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore7 = 0
positiveScore7 = 30  # 根据量表7得出
scaleMap7_1 = {
    "A": 0,
    "B": 1,
}
scaleMap7_2 = {
    "A": 1,
    "B": 0,
}

# -------------------------------------
# 量表10的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore10 = 0
positiveScore10 = 50  # 根据量表10得出
scaleMap10 = {
    "A": 3,
    "B": 2,
    "C": 1,
    "D": 0
}

# -------------------------------------
# 量表16的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore16 = 0
positiveScore16 = 11  # 根据量表16得出
scaleMap16 = {
    "A": 2,
    "B": 1,
    "C": 0
}

# -------------------------------------
# 量表18的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore18 = 0
positiveScore18 = 23  # 根据量表18得出
scaleMap18 = {
    "A": 0,
    "B": 1,
    "C": 2
}

# -------------------------------------
# 量表24的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore24 = 0
positiveScore24 = 40  # 根据量表24得出
scaleMap24_1 = {
    "A": 1,
    "B": 2,
    "C": 3,
    "D": 4,
    "E": 5
}
scaleMap24_2 = {
    "A": 5,
    "B": 4,
    "C": 3,
    "D": 2,
    "E": 1
}

# -------------------------------------
# 量表25的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore25 = 0
positiveScore25 = 145  # 根据量表25得出
scaleMap25 = {
    "A": 4,
    "B": 3,
    "C": 2,
    "D": 1
}

# -------------------------------------
# 量表41的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore41 = 0
positiveScore41 = 4  # 根据量表41得出
scaleMap41 = {
    "A": 1,
    "B": 0,
    "C": -1
}

# -------------------------------------
# 量表48的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore48 = 0
positiveScore48 = 9  # 根据量表48得出
scaleMap48 = {
    "A": 0,
    "B": 1,
    "C": 2,
    "D": 3
}

# -------------------------------------
# 量表56的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore56 = 0
positiveScore56 = 21  # 根据量表56得出
scaleMap56 = {
    "A": 2,
    "B": 1,
    "C": 0
}

# -------------------------------------
# 量表59的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore59 = 0
positiveScore59 = 6  # 根据量表59得出
scaleMap59 = {
    "A": 2,
    "B": 1,
    "C": 0
}

# -------------------------------------
# 量表60的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore60 = 0
positiveScore60 = 4  # 根据量表60得出
scaleMap60 = {
    "A": 1,
    "B": 0
}

# -------------------------------------
# 量表61的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore61 = 0
positiveScore61 = 16  # 根据量表61得出
scaleMap61 = {
    "A": 0,
    "B": 1,
    "C": 2,
    "D": 3,
    "E": 4
}

# -------------------------------------
# 量表62的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore62 = 0
positiveScore62 = 14  # 根据量表62得出
scaleMap62 = {
    "A": 0,
    "B": 1,
    "C": 2
}

# -------------------------------------
# 量表63的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore63 = 0
positiveScore63 = 4  # 根据量表63得出
scaleMap63 = {
    "A": 0,
    "B": 0,
    "C": 1
}

# -------------------------------------
# 量表64的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore64 = 0
positiveScore64 = 16  # 根据量表64得出
scaleMap64 = {
    "A": 1,
    "B": 2,
    "C": 3
}

# -------------------------------------
# 量表65的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore65 = 0
positiveScore65 = 10  # 根据量表65得出
scaleMap65 = {
    "A": 0,
    "B": 1,
    "C": 2,
    "D": 3,
    "E": 4
}

# -------------------------------------
# 量表66的参数设置：总分 阳性分 映射关系
# -------------------------------------
totalScore66 = 0
positiveScore66 = 48  # 根据量表66得出
scaleMap66 = {
    "A": 0,
    "B": 1,
    "C": 2,
    "D": 3,
    "E": 4,
    "F": 5,
    "G": 6
}


def calculate4(num, opt):
    '''
    计算量表4的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore4  # 声明为全局变量
    answers.append(["scale4", num, opt])  # 记录答题情况
    score = scaleMap4_1[opt] if num in [3, 5, 6, 10, 14, 15, 17, 18] else scaleMap4_2[opt]
    totalScore4 += score  # 新增分数
    isPositive = True if totalScore4 >= positiveScore4 else False  # 是否为阳性

    return totalScore4, isPositive


def calculate5(num, opt):
    '''
    计算量表5的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore5  # 声明为全局变量
    answers.append(["scale5", num, opt])  # 记录答题情况
    totalScore5 += scaleMap5[opt]  # 新增分数
    isPositive = True if totalScore5 >= positiveScore5 else False  # 是否为阳性

    return totalScore5, isPositive


def calculate6(num, opt):
    '''
    计算量表6的分数-----------------这个计算方法有误！
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore6  # 声明为全局变量
    answers.append(["scale6", num, opt])  # 记录答题情况
    totalScore6 += scaleMap6[opt]  # 新增分数
    isPositive = True if totalScore6 >= positiveScore6 else False  # 是否为阳性

    return totalScore6, isPositive


def calculate7(num, opt):
    '''
    计算量表7的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore7  # 声明为全局变量
    answers.append(["scale7", num, opt])  # 记录答题情况
    score = scaleMap7_1[opt] if num in [1, 2, 4, 5, 9, 10, 12, 13, 15, 17, 18, 21, 22, 24, 26, 27, 28, 29, 34, 35, 36,
                                        37, 40, 41, 43, 44, 45, 46, 48, 49, 52, 53, 54, 55, 59] else scaleMap7_2[opt]
    totalScore7 += score  # 新增分数
    isPositive = True if totalScore7 >= positiveScore7 else False  # 是否为阳性

    return totalScore7, isPositive


def calculate10(num, opt):
    '''
    计算量表10的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore10  # 声明为全局变量
    answers.append(["scale10", num, opt])  # 记录答题情况
    totalScore10 += scaleMap10[opt]  # 新增分数
    isPositive = True if totalScore10 >= positiveScore10 else False  # 是否为阳性

    return totalScore10, isPositive


def calculate16(num, opt):
    '''
    计算量表16的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore16  # 声明为全局变量
    answers.append(["scale16", num, opt])  # 记录答题情况
    totalScore16 += scaleMap16[opt]  # 新增分数
    isPositive = True if totalScore16 >= positiveScore16 else False  # 是否为阳性

    return totalScore16, isPositive


def calculate18(num, opt):
    '''
    计算量表18的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore18  # 声明为全局变量
    answers.append(["scale18", num, opt])  # 记录答题情况
    totalScore18 += scaleMap18[opt]  # 新增分数
    isPositive = True if totalScore18 >= positiveScore18 else False  # 是否为阳性

    return totalScore18, isPositive


def calculate24(num, opt):
    '''
    计算量表24的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore24
    answers.append(["scale24", num, opt])
    score = scaleMap24_1[opt] if num in [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21] else scaleMap24_2[opt]
    totalScore24 += score  # 新增分数
    isPositive = True if totalScore24 >= positiveScore24 else False

    return totalScore24, isPositive


def calculate25(num, opt):
    '''
    计算量表25的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore25
    answers.append(["scale25", num, opt])
    totalScore25 += scaleMap25[opt]
    isPositive = True if totalScore25 >= positiveScore25 else False
    return totalScore25, isPositive


def calculate41(num, opt):
    '''
    计算量表41的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore41
    answers.append(["scale41", num, opt])
    totalScore41 += scaleMap41[opt]
    isPositive = True if totalScore41 >= positiveScore41 else False
    return totalScore41, isPositive


def calculate48(num, opt):
    '''
    计算量表48的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore48
    answers.append(["scale48", num, opt])
    totalScore48 += scaleMap48[opt]
    isPositive = True if totalScore48 >= positiveScore48 else False
    return totalScore48, isPositive


def calculate56(num, opt):
    '''
    计算量表56的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore56
    answers.append(["scale56", num, opt])
    totalScore56 += scaleMap56[opt]
    isPositive = True if totalScore56 >= positiveScore56 else False
    return totalScore56, isPositive


def calculate59(num, opt):
    '''
    计算量表59的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore59
    answers.append(["scale59", num, opt])
    totalScore59 += scaleMap59[opt]
    isPositive = True if totalScore59 >= positiveScore59 else False
    return totalScore59, isPositive


def calculate60(num, opt):
    '''
    计算量表60的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore60
    answers.append(["scale60", num, opt])
    totalScore60 += scaleMap60[opt]
    isPositive = True if totalScore60 >= positiveScore60 else False
    return totalScore60, isPositive


def calculate61(num, opt):
    '''
    计算量表61的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore61
    answers.append(["scale61", num, opt])
    totalScore61 += scaleMap61[opt]
    isPositive = True if totalScore61 >= positiveScore61 else False
    return totalScore61, isPositive


def calculate62(num, opt):
    '''
    计算量表62的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore62
    answers.append(["scale62", num, opt])
    totalScore62 += scaleMap62[opt]
    isPositive = True if totalScore62 >= positiveScore62 else False
    return totalScore62, isPositive


def calculate63(num, opt):
    '''
    计算量表63的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore63
    answers.append(["scale63", num, opt])
    totalScore63 += scaleMap63[opt]
    isPositive = True if totalScore63 >= positiveScore63 else False
    return totalScore63, isPositive


def calculate64(num, opt):
    '''
    计算量表64的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore64
    answers.append(["scale64", num, opt])
    totalScore64 += scaleMap64[opt]
    isPositive = True if totalScore64 >= positiveScore64 else False
    return totalScore64, isPositive


def calculate65(num, opt):
    '''
    计算量表65的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore65
    answers.append(["scale65", num, opt])
    totalScore65 += scaleMap65[opt]
    isPositive = True if totalScore65 >= positiveScore65 else False
    return totalScore65, isPositive


def calculate66(num, opt):
    '''
    计算量表66的分数
    :param num: 题目的题号
    :param opt: 作答的选项
    :return: 返回当前总分和阳性情况
    '''
    global answers, totalScore66
    answers.append(["scale66", num, opt])
    totalScore66 += scaleMap66[opt]
    isPositive = True if totalScore66 >= positiveScore66 else False
    return totalScore66, isPositive


##############################################################
# part3-helper函数 ###########################################
##############################################################

def resetCalculator():
    # 重置全局变量
    global totalScore1, totalPositive1, totalScore2, totalPositive2, totalScore3, totalPositive3
    global totalScore4, totalScore5, totalScore6, totalScore7
    global totalScore10, totalScore16, totalScore18, totalScore24, totalScore25
    global totalScore41, totalScore48, totalScore56, totalScore59, totalScore60
    global totalScore61, totalScore62, totalScore63, totalScore64, totalScore65, totalScore66
    global totalPositive4, totalPositive5, totalPositive6, totalPositive7
    global totalPositive10, totalPositive16, totalPositive18, totalPositive24, totalPositive25
    global totalPositive41, totalPositive48, totalPositive56, totalPositive59, totalPositive60
    global totalPositive61, totalPositive62, totalPositive63, totalPositive64, totalPositive65, totalPositive66

    totalScore1 = {key: 0 for key in totalScore1}
    totalScore2 = {key: 0 for key in totalScore2}
    totalScore3 = {key: 0 for key in totalScore3}
    totalPositive1 = {key: False for key in totalPositive1}
    totalPositive2 = {key: False for key in totalPositive2}
    totalPositive3 = {key: False for key in totalPositive3}
    totalScore4 = 0
    totalScore5 = 0
    totalScore6 = 0
    totalScore7 = 0
    totalScore10 = 0
    totalScore16 = 0
    totalScore18 = 0
    totalScore24 = 0
    totalScore25 = 0
    totalScore41 = 0
    totalScore48 = 0
    totalScore56 = 0
    totalScore59 = 0
    totalScore60 = 0
    totalScore61 = 0
    totalScore62 = 0
    totalScore63 = 0
    totalScore64 = 0
    totalScore65 = 0
    totalScore66 = 0


def changeThreshold(index):
    global positiveScore2
    if index == 0:
        positiveScore2 = 12
    elif index == 1:
        positiveScore2 = 18
    elif index == 2:
        positiveScore2 = 24
    else:
        positiveScore2 = 30
