import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator

# 轻度 中等 重度 严重
composite_scale = ["Single Positivity", "Multiple Positivity", "Full Positivity"]

# 折线图坐标
size = len(composite_scale)
x = np.arange(size)
bar_colors = ['#ff8080', '#90EE90', '#8080ff']  # 为每组数据分配颜色
data = {
    "MHRSP": [67.72, 72.79, 76.06],
    "MSSMHS": [33.71, 64.49, 91.98],
    "SCL-90": [86.34, 86.16, 79.29],
}

fig = plt.figure()
ax1 = fig.add_subplot(111)

# 设置刻度间隔
y_major_locator = MultipleLocator(10)
ax1.yaxis.set_major_locator(y_major_locator)

# 绘制每组折线图
for i, (key, color) in enumerate(zip(data.keys(), bar_colors)):
    ax1.plot(x, data[key], color=color, marker='o', label=key)

ax1.set_ylim(bottom=0, top=100)
ax1.set_ylabel('Accuracy (min)')
ax1.set_xlabel('Conditions')
ax1.legend(loc='upper left')

plt.xticks(x, labels=composite_scale)
plt.title("Accuracy of different scales in the case of different positivity")

plt.show()


# exp_1_1:
# 耗时：[12.55, 23.12, 33.15, 31.78]
# 准确率：[67.72, 67.94, 68.11, 67.74]

# 耗时：[22.29, 43.9, 20.52, 23.84]
# 准确率：[72.79, 73.03, 73.24, 73.26]

# 耗时：[25.78, 25.67, 35.13, 37.8]
# 准确率：[76.06, 76.28, 76.21, 76.41]

# exp_1_2
# 耗时：[35.91, 22.24, 7.52, 7.52]
# 准确率：[33.71, 80.98, 90.19, 90.0]

# 耗时：[45.6, 19.14, 7.53, 7.52]
# 准确率：[64.49, 76.89, 56.66, 50.03]

# 耗时：[45.57, 39.63, 18.83, 7.52]
# 准确率：[91.98, 67.52, 14.25, 0.01]

# exp_1_3
# 耗时：[28.09, 33.4, 27.21, 31.78]
# 准确率：[86.74, 86.43, 86.34, 86.49]

# 耗时：[34.33, 39.07, 38.13, 45.14]
# 准确率：[86.16, 85.94, 86.0, 85.69]

# 耗时：[46.98, 45.63, 45.89, 48.81]
# 准确率：[79.29, 79.5, 79.36, 79.06]
