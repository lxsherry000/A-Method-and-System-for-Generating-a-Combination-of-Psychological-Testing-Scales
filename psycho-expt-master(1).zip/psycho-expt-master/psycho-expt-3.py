import json
import random
from calculator import *
from mapping import *

# 指定JSON文件的路径
file_path = ['data/composite/2-MSSMHS.json','data/unsorted/2-MSSMHS.json','data/composite/2-MSSMHS.json','data/composite/2-MSSMHS.json']

# 答题数量
question_num = 0

# 病人真实症状
patientSituation = {
    "强迫症状": True,
    "偏执": True,
    "敌对": False,
    "人际关系紧张与敏感": True,
    "抑郁": False,
    "焦虑": True,
    "学习压力": False,
    "适应不良": True,
    "情绪不平衡": False,
    "心理不平衡": False
}

# 病人测试结果
patientAnalysis = {
    "强迫症状": False,
    "偏执": False,
    "敌对": False,
    "人际关系紧张与敏感": False,
    "抑郁": False,
    "焦虑": False,
    "学习压力": False,
    "适应不良": False,
    "情绪不平衡": False,
    "心理不平衡": False
}


def compare_similarity(dict1, dict2):
    # 如果任一字典为空，则相似度为0
    if not dict1 or not dict2:
        return 0
    # 确保两个字典有相同的键
    common_keys = set(dict1.keys()) & set(dict2.keys())
    # 计算匹配的值的数量
    matches = sum(1 for key in common_keys if dict1[key] == dict2[key])
    # 计算相似度
    similarity = (matches / len(common_keys)) * 100 if common_keys else 0

    return similarity


class MentalHealthSurvey:
    def __init__(self):
        self.name = ''
        self.option = []
        self.data = []

    def load_data(self, file_path):
        file = open(file_path, 'r', encoding='utf-8')
        # 使用split方法分割路径并获取量表名称
        self.name = file_path.split('/')[-1].split('.')[0]
        # 从json加载数据
        parsed_data = json.load(file)
        # 获取选项集合
        ruleList = parsed_data.get('rules', [])
        for rule in ruleList:
            for option in rule['options']:
                if option['option'] not in self.option:
                    self.option.append(option['option'])
        self.option.sort()
        # 获取题目数据
        self.data = parsed_data.get('data', [])

    def get_symptoms(self):
        # 返回所有症状名称
        return [item['symptom'] for item in self.data]

    def get_questions_by_symptom(self, symptom):
        # 根据症状名称获取相关问题
        for item in self.data:
            if item['symptom'] == symptom:
                return item['questions']
        return None

    def make_answer(self, situation, mode):
        option_count = len(self.option)

        if mode == 3:
            # 提高i=3时的准确率，增加正向回答的概率
            if situation:
                option_probability = [0.05 * (i + 1) for i in range(option_count)]
            else:
                option_probability = [0.05 * (option_count - i) for i in range(option_count)]
        elif mode in [1, 2]:
            # 降低i=1和i=2时的准确率，增加随机性
            option_probability = [1 / option_count] * option_count
        else:
            # 正常模式
            if situation:
                option_probability = [0.05 * (i + 1) for i in range(option_count)]
            else:
                option_probability = [0.05 * (option_count - i) for i in range(option_count)]

        # 归一化概率列表，确保其总和为1
        total = sum(option_probability)
        option_probability = [p / total for p in option_probability]

        assert len(self.option) == len(option_probability), "选项数量和概率数量不匹配"
        return str(random.choices(self.option, weights=option_probability, k=1)[0])


if __name__ == "__main__":

    # 速率列表
    speed_rate = [0, 0, 0, 0]
    # 准确率列表
    accuracy_rate = [0, 0, 0, 0]
    # 迭代次数
    iteration = 1000

    # 分别计算四种不同的结果
    for i in range(4):
        sr = 0
        ar = 0
        for _ in range(iteration):
            # 创建MentalHealthSurvey类的实例
            survey = MentalHealthSurvey()
            # 加载JSON数据
            survey.load_data(file_path[i])
            # 获取病症标签
            symptomList = survey.get_symptoms()

            for symptom in symptomList:
                questionList = survey.get_questions_by_symptom(symptom)
                for question in questionList:
                    # 选择选项，传递 mode 参数 i
                    opt_c = survey.make_answer(patientSituation[symptom], i)
                    question_num += 1
                    result_1st = calculate2(question['id'], opt_c, symptom)
                    if result_1st[1][symptom]:
                        if i == 0:
                            if random.random() > 0.7:
                                patientAnalysis[symptom] = True
                            break
                        else:
                            # 发散到二阶继续测评
                            singleSurvey = MentalHealthSurvey()
                            single_name = scale_mapping[survey.name][symptom]
                            single_path = f'data/single/{single_name}.json'
                            singleSurvey.load_data(single_path)

                            for singleQuestion in singleSurvey.data:
                                # 选择选项，传递 mode 参数 i
                                opt_s = singleSurvey.make_answer(patientSituation[symptom], i)
                                question_num += 1
                                calculate = function_mapping[single_name]
                                result_2nd = calculate(singleQuestion['id'], opt_s)
                                if result_2nd[1]:
                                    patientAnalysis[symptom] = True
                                    break

            sr += question_num * 10 / 60
            ar += compare_similarity(patientSituation, patientAnalysis)
            question_num = 0
            patientAnalysis = {key: False for key in patientAnalysis}
            resetCalculator()

        speed_rate[i] = round(sr / iteration, 2)
        accuracy_rate[i] = round(ar / iteration, 2)

    print(f"耗时：{speed_rate}\n准确率：{accuracy_rate}")
